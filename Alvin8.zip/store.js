exports.panel = `🧷 *WTS PANEL BY ALVIN*🧷

🖥️ _*SPEAK SERVER RAM 32GB CORE 8 DIGITAL OCEAN NO SUSPEN*_ 🖥️

🛒 _RAM 4GB CPU 120% 💸 5.000/BULAN_
🛒 _RAM 5GB CPU 150% 💸 7.000/BULAN_
🛒 _RAM 10GB CPU 300%   💸14.000/BULAN_
🛒 _UNLIMETED RAM & CPU  💸16.000/BULAN_
🛒 _DAN UNTUK SPESIFIKASI REQUEST RAM DAN CPU LAIN NYA BISA CHAT ADMIN_

📦 *SPESIAL PERPANJANG PANEL SPEAK UNLIMITED 10.000* 📦

🛡️ *KEUNTUNGAN* 🛡️
*•BOT ON 24JAM*
*•WEB CLOSE BOT TETAP ON*
*•GARANSI FULL*
*•JUAL GA ASAL JUAL*
*•PANEL TENTUNYA BERKUALITAS JADI ADA HARGA BUAT ITU*
*•ANTI CURI CURI SC*
*•ADMIN AKAN REFF PENUH DANA ANDA JIKA TERJADI KEHILANGAN SC*
*•GARANSI 30DAYS FULL*

⚠️ _NOTE_ ⚠️
_SERVER INI GW SENDIRI YG NGURUS LANGSUNG DAN TIDAK ADA ADMIN DAN RESELLER PANEL LAIN NYA JADI SC KALIAN AMAN TANPA DI CURI..!!_

*✉️Minat??",Chat admin!!✉️*
*▬▭▬▭▬▭▬▭▬▭▬▭▬▭*
*wa.me/6283849706098* *(Alvin)*
*▬▭▬▭▬▭▬▭▬▭▬▭▬▭*
*https://www.youtube.com/@callmevinz*
*▬▭▬▭▬▭▬▭▬▭▬▭▬▭*
_⚠️Note⚠️_
_PASTIKAN ANDA MEMILIKI SALDO JIKA BELUM SILAHKAN DEPOSIT KETIK *.deposit*_`

exports.vps = `*🧷WTS VPS DIGITAL OCEAN🧷*

*🖥️SPEAK🖥️*

🛒 _RAM 1 CORE 1 💸 20.000/BULAN_
🛒 _RAM 2 CORE 1 💸 30.000/BULAN_
🛒 _RAM 4 CORE 2 💸 50.000/BULAN_
🛒 _RAM 8 CORE 4 💸 70.000/BULAN_

*🖥️VPS DIGITAL OCEAN ADALAH VPS YG KECIL KEMUNGKINAN UNTUK TERKENA SUSPEN DI BANDINGKAN DENGAN LINODE DAN YNG LAIN🖥️*

*🛡️KEUNTUNGAN🛡️*
*•SERVER MILIK SENDIRI*
*•BISA JADI KANG PANEL*
*•BISA JUALAN PANEL*
*•BISA BALMOD JIKA SERIUS JUALAN PANEL NYA*
*•GARANSI 10D JIKA TIDAK MELANGGAR TOS*
*•FREE INSTALL PANEL*
*•KECIL KEMUNGKINAN SERVER TERKENA SUSPEN

*✉️Minat??",Chat admin!!✉️*
*=======================*
*wa.me/6283849706098*
_⚠️Note⚠️_
_PASTIKAN ANDA MEMILIKI SALDO JIKA BELUM SILAHKAN DEPOSIT KETIK *.deposit*_`

exports.subdomain = `▭▬▭( *LIST DOMAIN PRIVATE* )▭▬▭

┏━━━━━━━━━━━━━━━━━━━
┣domain1 panellstore.com
┣domain2 panellstore.net
┣domain3 panellstore.icu
┣domain4 panellstore.xyz
┣domain5 panellstore.art
┣domain6 panellkuu.com
┣domain7 jasa-panel.my.id 
┣domain8 didinsec.biz.id 
┣domain9 putraoffc.cfd 
┣domain10 sellerpannel.my.id 
┣domain11 pannelku.icu
┣domain12 pannelku.cfd
┣domain13 putraoffc.site
┣domain14 putraoffc.com 
┣domain15 kangpannel.xyz 
┣domain16 mypannelku.com 
┣domain17 pannelmurah.xyz
┣domain18 storepannel.xyz
┣domain19 tokopannel.xyz
┣domain20 mypannel.cfd
┣domain21 adminpannel.xyz
┣domain22 mypannel.icu
┣domain23 tokocpannelmurah.xyz
┣domain24 websitepannelmurah.com
┣domain25 panellku.my.id
┣domain26 panellku.me 
┣domain27 panellku.biz.id 
┣domain28 panellku.tech 
┣domain29 panelkuu.xyz
┣domain30 panellku.com
┣domain31 biistoreee.tech
┣domain32 biistoreee.xyz 
┣domain33 rulzxyxd.com 
┣domain34 rafatharoffc.dev
┣domain35 rafatharoffcial.dev
┣domain36 rizalshop.my.id
┣domain37 panelku.link
┣domain38 sanzyy.xyz
┣domain39 home-panel.pw ( prem )
┣domain40 aswinxd.me
┣domain41 panel-zall.me ( prem )
┣domain42 digital-market.me
┣domain43 rafatharofficial.my.id
┣domain44 tokodigital.software
┣domain45 agen-panell.tech ( prem )
┣domain46 privateyour.me ( owner )
┣domain47 crazyyhosting.xyz
┣domain48 servershop.biz.id
┣domain49 rumahpanel.xyz ( prem ) 
┣domain50 controlpanel.site ( prem )
┣domain51 sellerpanel.me ( prem )
┣domain52 panelstoree.tech ( prem )
┣domain53 toko-pannelmurah.biz.id ( prem )
┣domain54 vvip-pannel.online ( prem ) 
┣domain55 rafatharoffcial-private.me ( prem )
┣domain56 amaliasyva-private.tech ( prem )
┣domain57 kangpane.me ( prem )
┣domain58 rizalxalfi.com ( prem )
┗━━━━━━━━━━━━━━━━━━━
▬▭▬▭▬▭▬▭▬▭▬▭▬
*✉️Minat??,,Chat admin!✉️*
*wa.me/6283849706098*
▬▭▬▭▬▭▬▭▬▭▬▭▬
_⚠️Note⚠️_
_PASTIKAN ANDA MEMILIKI SALDO JIKA BELUM SILAHKAN DEPOSIT KETIK *.deposit*_`


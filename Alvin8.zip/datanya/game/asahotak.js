exports.anu = [
  {
    "index": 0,
    "soal": "Pertanyaan",
    "jawaban": "Jawaban"
  },
  {
    "index": 1,
    "soal": "Hewan sejenis kadal yang dapat merubah warna kulitnya?",
    "jawaban": "Bunglon"
  },
  {
    "index": 2,
    "soal": "Surat instruksi kepada Soeharto untuk mengambil alih keamanan Indonesia pada tanggal 11 Maret 1966?",
    "jawaban": "Supersemar"
  },
  {
    "index": 3,
    "soal": "Sungai terpanjang di Benua Amerika?",
    "jawaban": "Amazon"
  },
  {
    "index": 4,
    "soal": "Wanita yang tercatat dalam sejarah sebagai penjahit Bendera Pusaka Indonesia?",
    "jawaban": "Fatmawati"
  },
  {
    "index": 5,
    "soal": "Lomba lari jarak jauh sepanjang 42,195 km?",
    "jawaban": "Marathon"
  },
  {
    "index": 6,
    "soal": "Garis yang membagi Bumi menjadi dua bagian belahan utara dan belahan selatan?",
    "jawaban": "Khatulistiwa"
  },
  {
    "index": 7,
    "soal": "Kota yang berdiri sejak tahun 682 ini disebut sebagai kota tertua di Indonesia?",
    "jawaban": "Palembang"
  },
  {
    "index": 8,
    "soal": "Sebutan untuk gaya tarik-menarik yang terjadi di alam semesta termasuk Bumi?",
    "jawaban": "Gravitasi"
  },
  {
    "index": 9,
    "soal": "Nama film yang bercerita tentang robot yang dapat berubah menjadi kendaran?",
    "jawaban": "Transformers"
  },
  {
    "index": 10,
    "soal": "Petarung di zaman Romawi Kuno yang melakukan pertarungan untuk hiburan umum?",
    "jawaban": "Gladiator"
  },
  {
    "index": 11,
    "soal": "Nama kapal penumpang mewah yang tenggelam saat pelayaran perdana tahun 1912?",
    "jawaban": "Titanic"
  },
  {
    "index": 12,
    "soal": "Klub sepak bola dari Italia yang memiliki julukan Nyonya Tua?",
    "jawaban": "Juventus"
  },
  {
    "index": 13,
    "soal": "Mekanisme sistem pemerintahan negara yang berdasarkan kehendak rakyat?",
    "jawaban": "Demokrasi"
  },
  {
    "index": 14,
    "soal": "Nama kesenian drama tari tradisional yang khas dari Bali?",
    "jawaban": "Kecak"
  },
  {
    "index": 15,
    "soal": "Nama mata uang yang digunakan di negara Rusia?",
    "jawaban": "Rubel"
  },
  {
    "index": 16,
    "soal": "Ilmu alam yang mengamati benda langit serta fenomena di luar atmosfer Bumi?",
    "jawaban": "Astronomi"
  },
  {
    "index": 17,
    "soal": "Kaisar Prancis yang menguasai Benua Eropa pada tahun 1803-1815?",
    "jawaban": "Napoleon"
  },
  {
    "index": 18,
    "soal": "Seniman terkenal dunia dari Spanyol dengan aliran seni bernama kubisme?",
    "jawaban": "Picasso"
  },
  {
    "index": 19,
    "soal": "Nama panglima tertinggi Pasukan Sekutu pada Perang dunia II?",
    "jawaban": "Eisenhower"
  },
  {
    "index": 20,
    "soal": "Senjata fiksi dalam dunia Star Wars, digunakan oleh Jedi dan Sith?",
    "jawaban": "Lightsaber"
  },
  {
    "index": 21,
    "soal": "Nama semenanjung di Eropa dimana terdapat negara Norwegia dan Swedia?",
    "jawaban": "Skandinavia"
  },
  {
    "index": 22,
    "soal": "Stadion sepak bola di London yang juga markas utama klub Arsenal FC?",
    "jawaban": "Emirates"
  },
  {
    "index": 23,
    "soal": "Penyanyi wanita terkenal dunia, dulu berada dalam grup Destiny’s Child?",
    "jawaban": "Beyonce"
  },
  {
    "index": 24,
    "soal": "Istilah untuk sebuah kepercayaan bahwa Tuhan adalah satu atau tunggal?",
    "jawaban": "Monoteisme"
  },
  {
    "index": 25,
    "soal": "Nama kerajaan dimana rajanya menjadi wakil Gubernur DI Yogyakarta saat ini?",
    "jawaban": "Pakualaman"
  },
  {
    "index": 26,
    "soal": "Disebut sebagai salah satu matematikawan terbesar sejarah, lahir pada 287 SM?",
    "jawaban": "Archimedes"
  },
  {
    "index": 27,
    "soal": "Rangkaian pegunungan tertinggi di Indonesia, terletak di Pulau Papua?",
    "jawaban": "Jayawijaya"
  },
  {
    "index": 28,
    "soal": "Kelompok fiksi superhero yang terdiri dari Iron Man, Captain America, Hulk, Thor?",
    "jawaban": "Avengers"
  },
  {
    "index": 29,
    "soal": "Nama wilayah luas di Rusia, meliputi hampir seluruh wilayah Asia Utara?",
    "jawaban": "Siberia"
  },
  {
    "index": 30,
    "soal": "Suatu benda atau media yang menghantarkan arus listrik dengan mudah?",
    "jawaban": "Konduktor"
  },
  {
    "index": 31,
    "soal": "Nama bahasa yang digunakan di Iran, Tajikistan, Afganistan, dan Uzbekistan?",
    "jawaban": "Farsi"
  },
  {
    "index": 32,
    "soal": "Daerah dimana terdapat praktik pertanian pertama sekitar tahun 8000 SM?",
    "jawaban": "Mesopotamia"
  },
  {
    "index": 33,
    "soal": "Ideologi yang berdasarkan pada prinsip kepemimpinan dengan otoritas absolut?",
    "jawaban": "Fasisme"
  },
  {
    "index": 34,
    "soal": "Nama periode geologi dari 252 ke 66 juta tahun yang lalu, disebut juga Zaman Reptil?",
    "jawaban": "Mesozoikum"
  },
  {
    "index": 35,
    "soal": "Nama yang dikenal dalam legenda Jawab sebagai arsitek perancang Candi Borobudur?",
    "jawaban": "Gunadharma"
  },
  {
    "index": 36,
    "soal": "Tarian tradisional Tionghoa yang menggunakan kostum menyerupai singa",
    "jawaban": "Barongsai"
  },
  {
    "index": 37,
    "soal": "Istilah yang artinya perpindahan penduduk dari desa ke kota?",
    "jawaban": "Urbanisasi"
  },
  {
    "index": 38,
    "soal": "Grup musik terkenal tahun 1970an asal Bandung, personelnya tiga bersaudara?",
    "jawaban": "Bimbo"
  },
  {
    "index": 39,
    "soal": "Nama film aksi laga Indonesia tahun 2009 yang dibintangi oleh Iko Uwais?",
    "jawaban": "Merantau"
  },
  {
    "index": 40,
    "soal": "Dikenal sebagai “maestro keroncong Indonesia”, pencipta lagu Bengawan Solo?",
    "jawaban": "Gesang"
  },
  {
    "index": 41,
    "soal": "Skala suhu dimana titik beku air berada pada 0 derajat dan titik didih pada 100 derajat?",
    "jawaban": "Celcius"
  },
  {
    "index": 42,
    "soal": "Makhluk halus mitos Jawa, berwujud manusia mirip kera, bertubuh besar dan berbulu?",
    "jawaban": "Genderuwo"
  },
  {
    "index": 43,
    "soal": "Sebuah distrik di Los Angeles yang terkenal dengan industri perfilmannya yang mendunia?",
    "jawaban": "Hollywood"
  },
  {
    "index": 44,
    "soal": "Cabang biologi yang mempelajari pewarisan sifat pada organisme maupun suborganisme?",
    "jawaban": "Genetika"
  },
  {
    "index": 45,
    "soal": "Situs manusia purba di Jawa Tengah, juga merupakan Situs Warisan Dunia UNESCO?",
    "jawaban": "Sangiran"
  },
  {
    "index": 46,
    "soal": "Bongkahan batu yang berukuran lebih kecil daripada planet, mengorbit Matahari?",
    "jawaban": "Asteroid"
  },
  {
    "index": 47,
    "soal": "Istilah untuk hewan pemakan rerumputan atau tumbuhan?",
    "jawaban": "Herbivora"
  },
  {
    "index": 48,
    "soal": "Istilah yang berarti pembantaian sistematis terhadap suatu suku atau kelompok?",
    "jawaban": "Genosida"
  },
  {
    "index": 49,
    "soal": "Nama penyakit demam yang ditularkan oleh nyamuk Anopheles betina?",
    "jawaban": "Malaria"
  },
  {
    "index": 50,
    "soal": "Nama tokoh fiksi budaya Sunda yang sifatnya lucu, polos, tetapi sekaligus cerdas?",
    "jawaban": "Kabayan"
  },
  {
    "index": 51,
    "soal": "Asrama tempat belajar para siswa santri yang dibimbin oleh Kiai?",
    "jawaban": "Pesantren"
  },
  {
    "index": 52,
    "soal": "Perusahaan video game dari Jepang, pencipta Mario Bros dan Pokemon?",
    "jawaban": "Nintendo"
  },
  {
    "index": 53,
    "soal": "Sebuah agama resmi di Indonesia yang berdasarkan pada ajaran Konfusius?",
    "jawaban": "Khong hu cu"
  },
  {
    "index": 54,
    "soal": "Nama ensiklopedia online yang bebas ditulis dan disunting oleh siapa saja?",
    "jawaban": "Wikipedia"
  },
  {
    "index": 55,
    "soal": "Bangun datar segi empat, sepasang sisi sejajar namun tidak sama panjang?",
    "jawaban": "Trapesium"
  },
  {
    "index": 56,
    "soal": "Penyakit dimana hormon pengatur gula dara dari tubuh tidak mencukupi?",
    "jawaban": "Diabetes"
  },
  {
    "index": 57,
    "soal": "Negara independen terkecil di dunia yang diakui secara internasional?",
    "jawaban": "Vatikan"
  },
  {
    "index": 58,
    "soal": "Kekaisaran kuno di wilayah Yunani yang dipimpin oleh Aleksander Agung?",
    "jawaban": "Makedonia"
  },
  {
    "index": 59,
    "soal": "Negara dengan jumlah penduduk Muslim terbanyak kedua di dunia?",
    "jawaban": "Pakistan"
  },
  {
    "index": 60,
    "soal": "Gejala penurunan fungsi otak, umumnya terjadi pada usia lanjut?",
    "jawaban": "Demensia"
  },
  {
    "index": 61,
    "soal": "Bahan bakar fosil, digunakan di Pembangkit Listrik Tenaga Uap?",
    "jawaban": "Batu bara"
  },
  {
    "index": 62,
    "soal": "Nama pura terkenal di Bali yang dibangun pada ujung batu karang?",
    "jawaban": "Uluwatu"
  },
  {
    "index": 63,
    "soal": "Sebuah gelar yang diperoleh putra Sultan Agung dari Mataram?",
    "jawaban": "Amangkurat"
  },
  {
    "index": 64,
    "soal": "Seorang yang bertugas merawat bayi atau anak pada suatu keluarga?",
    "jawaban": "Pramusiwi"
  },
  {
    "index": 65,
    "soal": "Daerah di Jepang dimana terjadi kebocoran nuklir pada tahun 2011?",
    "jawaban": "Fukushima"
  },
  {
    "index": 66,
    "soal": "Perlindungan finansial untuk jiwa kesehatan properti dsb?",
    "jawaban": "Asuransi"
  },
  {
    "index": 67,
    "soal": "Perusahaan berlogo kuda asal Italia produsen mobil super dan mobil balap?",
    "jawaban": "Ferrari"
  },
  {
    "index": 68,
    "soal": "Suku dari sulawesi selatan yang terkenal sebagai pelaut ulung?",
    "jawaban": "BugisVampir yang"
  },
  {
    "index": 69,
    "soal": "Vampir yang merupakan tokoh utama fiksi ciptaan Bram Stoker?",
    "jawaban": "Drakula"
  },
  {
    "index": 70,
    "soal": "Planet ini merupakan planet terbesar di Tata Surya?",
    "jawaban": "Yupiter"
  },
  {
    "index": 71,
    "soal": "Tanaman yang dipakai sebagai bahan pembuat kertas pada Zaman Mesir Kuno?",
    "jawaban": "Papirus"
  },
  {
    "index": 72,
    "soal": "Bahan peledak berupa bubuk campuran dari belerang, arang, dan kalium nitrat?",
    "jawaban": "Mesiu"
  },
  {
    "index": 73,
    "soal": "Bahasa resmi yang juga digunakan secara luas di Negara Filipina?",
    "jawaban": "Tagalog"
  },
  {
    "index": 74,
    "soal": "Negara kecil di Amerika Selatan, terdapat banyak keturunan Suku Jawa?",
    "jawaban": "Suriname"
  },
  {
    "index": 75,
    "soal": "Kuda jantan bersayap dari mitologi Yunani?",
    "jawaban": "Pegasus"
  },
  {
    "index": 76,
    "soal": "Grup musik Rock alternatif dari London. vokalisnya bernama Chris Martin?",
    "jawaban": "Coldplay"
  },
  {
    "index": 77,
    "soal": "Buah yang jika dipotong mempunyai penampang berbentuk bintang?",
    "jawaban": "Belimbing"
  },
  {
    "index": 78,
    "soal": "Ensembel musik yang biasanya menonjolkan metalofon, gambang, gendang, dan gong?",
    "jawaban": "Gamelan"
  },
  {
    "index": 79,
    "soal": "Nama kota yang selama beberapa abad diperebutkan oleh Islam, Kristen, Yahudi?",
    "jawaban": "Yerusalem"
  },
  {
    "index": 80,
    "soal": "Bahasa resmi negara Bangladesh, digunakan oleh sekitar 200 juta orang?",
    "jawaban": "Bengali"
  },
  {
    "index": 81,
    "soal": "Minuman memabukkan yang berbahan dasar etanol?",
    "jawaban": "Alkohol"
  },
  {
    "index": 82,
    "soal": "Satu-satunya gunung berapi aktif di Eropa Daratan yang letaknya di Italia?",
    "jawaban": "Vesuvius"
  },
  {
    "index": 83,
    "soal": "Karakter fiksi berambut sangat panjang tokoh utama film animasi Tangled?",
    "jawaban": "Rapunzel"
  },
  {
    "index": 84,
    "soal": "Bencana alam berupa gelombang ombak besar dari laut?",
    "jawaban": "Tsunami"
  },
  {
    "index": 85,
    "soal": "Nama kota di negara Turki yang zaman dulu bernama Konstantinopel?",
    "jawaban": "Istanbul"
  },
  {
    "index": 86,
    "soal": "Subspesies manusia yang punah dari muka bumi sekitar 30.000 tahun yang lalu?",
    "jawaban": "Neanderthal"
  },
  {
    "index": 87,
    "soal": "Nama ritual bunuh diri kaum Samurai di Jepang dengan cara merobek perut?",
    "jawaban": "Seppuku"
  },
  {
    "index": 88,
    "soal": "Jenis keju asal Italia yang seringkali terdapat pada hidangan pizza?",
    "jawaban": "Mozzarella"
  },
  {
    "index": 89,
    "soal": "Gelar bagi istri dari penguasa monarki pria(raja, sultan, atau kaisar)?",
    "jawaban": "Permaisuri"
  },
  {
    "index": 90,
    "soal": "Nama suku yang sejak lama mendiami daerah kutub utara bumi?",
    "jawaban": "Eskimo"
  },
  {
    "index": 91,
    "soal": "Unsur paling berlimpah kedua setelah oksigen pada tubuh manusia?",
    "jawaban": "Karbon"
  },
  {
    "index": 92,
    "soal": "Peristiwa genosida terhadap penganut Yahudi Eropa selama Perang Dunia II?",
    "jawaban": "Holokaus"
  },
  {
    "index": 93,
    "soal": "Proses perubahan gula menjadi etanol yang dilakukan oleh ragi?",
    "jawaban": "Fermentasi"
  },
  {
    "index": 94,
    "soal": "Ramalan dalam tradisi jawa yang membahas mengenai adanya ratu adil?",
    "jawaban": "Jayabaya"
  },
  {
    "index": 95,
    "soal": "Tokoh abad ke 15 dari Polandia yang mencetuskan teori heliosentrisme?",
    "jawaban": "Copernicus"
  },
  {
    "index": 96,
    "soal": "Alat populer untuk menyambung dua sisi kain, digunakan dalam pakaian, tas, dsb?",
    "jawaban": "Ritsleting"
  },
  {
    "index": 97,
    "soal": "Satuan perbedaan potensi listrik antara dua titik dalam rangkaian listrik?",
    "jawaban": "Voltase"
  },
  {
    "index": 98,
    "soal": "Sistem sosial yang memberikan kekuasaan besar kepada golongan bangsawan?",
    "jawaban": "Feodalisme"
  },
  {
    "index": 99,
    "soal": "Nama pemanis buatan/sintetis yang tersusun dari dua macam asam amino?",
    "jawaban": "Aspartam"
  },
  {
    "index": 100,
    "soal": "Konsol permainan video yang pertama kali diproduksi oleh Sony tahun 1990an?",
    "jawaban": "PlayStation"
  },
  {
    "index": 101,
    "soal": "Nama lain pulau Kalimantan, digunakan saat zaman pemerintahan Hindia Belanda?",
    "jawaban": "Borneo"
  },
  {
    "index": 102,
    "soal": "Batu permata atau batu mulia yang warnanya pada kisaran hijau?",
    "jawaban": "Zamrud"
  },
  {
    "index": 103,
    "soal": "Nama museum sejarah dan kebudayaan jawa yang berada di Yogyakarta?",
    "jawaban": "Sonobudoyo"
  },
  {
    "index": 104,
    "soal": "Cabang ilmu kedokteran yang mempelajari aspek kesehatan jiwa dan tubuh manusia?",
    "jawaban": "Psikiatri"
  },
  {
    "index": 105,
    "soal": "Presiden pertama Amerika Serikat, juga menjadi nama Ibukota Amerika Serikat?",
    "jawaban": "Washingthon"
  },
  {
    "index": 106,
    "soal": "Satu-satunya jenis hewan mamalia yang bisa terbang?",
    "jawaban": "Kelelawar"
  },
  {
    "index": 107,
    "soal": "Gugus kepulauan Oseania, terdiri lebih dari 1000 kepulauan?",
    "jawaban": "Polinesia"
  },
  {
    "index": 108,
    "soal": "Gelar penguasa monarki zaman kerajaan, tingkatnya setara dengan kaisar?",
    "jawaban": "Maharaja"
  },
  {
    "index": 109,
    "soal": "Nama pulau yang paling berdekatan dengan negara Singapura?",
    "jawaban": "Batam"
  },
  {
    "index": 110,
    "soal": "Cabang angkatan bersenjata berkemampuan melakukan penyerbuan secara amfibi?",
    "jawaban": "Marinir"
  },
  {
    "index": 111,
    "soal": "Perusahaan operator seluler di Indonesia dengan pelanggan terbanyak?",
    "jawaban": "Telkomsel"
  },
  {
    "index": 112,
    "soal": "Nama binatang bercangkang dan berkaki 10?",
    "jawaban": "Kepiting"
  },
  {
    "index": 113,
    "soal": "Benda miniatur untuk menggabarkan suatu pemandangan atau suatu adegan?",
    "jawaban": "Diorama"
  },
  {
    "index": 114,
    "soal": "Rumah adat masyarakat Toraja, atapnya melengkung menyerupai perahu?",
    "jawaban": "Tonkonan"
  },
  {
    "index": 115,
    "soal": "Gua yang menjadi markas besar pangeran Diponegoro pada tahun 1825?",
    "jawaban": "Selarong"
  },
  {
    "index": 116,
    "soal": "Sebutan untuk makhluk berwujud perempuan yang tinggal di kahyangan/surga?",
    "jawaban": "Bidadari"
  },
  {
    "index": 117,
    "soal": "Pedang melengkung satu mata yang digunakan para Samurai Jepang?",
    "jawaban": "Katana"
  },
  {
    "index": 118,
    "soal": "Bahan perhiasan yang diproduksi di dalam jaringan lunak hewan moluska?",
    "jawaban": "Mutiara"
  },
  {
    "index": 119,
    "soal": "Nama perusahaan dari Finlandia pengembang game Clash of Clans?",
    "jawaban": "Supercell"
  },
  {
    "index": 120,
    "soal": "Minuman tradisional khas Sunda, berbahan utama gula aren dan santan?",
    "jawaban": "Bajigur"
  },
  {
    "index": 121,
    "soal": "Aliran musik yang awalnya dikembangkan di jamaika pada tahun 1960an?",
    "jawaban": "Reggae"
  },
  {
    "index": 122,
    "soal": "Drama tradisional dari Jawa Timur, bersifat menghibur dan membuat tertawa?",
    "jawaban": "Ludruk"
  },
  {
    "index": 123,
    "soal": "Nama asrama sekolah fiksi dimana tokoh Harry Potter belajar sihir?",
    "jawaban": "Hogwarts"
  },
  {
    "index": 124,
    "soal": "Kota yang asal mula namanya berasal dari sejarahnya sebagai pembuat terasi?",
    "jawaban": "Cirebon"
  },
  {
    "index": 125,
    "soal": "Pejabat umum dalam bidang hukum yang berwenang membuat akta otentik?",
    "jawaban": "Notaris"
  },
  {
    "index": 126,
    "soal": "Jenis gula yang diproses dari karbohidrat oleh tubuh manusia?",
    "jawaban": "Glukosa"
  },
  {
    "index": 127,
    "soal": "Pisau genggam kecil berbentuk melengkung khas dari Asia Tenggara?",
    "jawaban": "Kerambit"
  },
  {
    "index": 128,
    "soal": "Spesies gajah purba dari genus mamut, pemakan dedaunan dan dahan pohon?",
    "jawaban": "Mastodon"
  },
  {
    "index": 129,
    "soal": "Sumpah yang dikemukakan Gajah Mada pada upacara pengangkatannya menjadi Patih?",
    "jawaban": "Palapa"
  },
  {
    "index": 130,
    "soal": "Produk simpanan di bank, penarikannya hanya bisa dilakukan pada waktu tertentu saja?",
    "jawaban": "Deposito"
  },
  {
    "index": 131,
    "soal": "Gejala optik dan meteorologi berupa cahaya beraneka warna yang tampak di langit?",
    "jawaban": "Pelangi"
  },
  {
    "index": 132,
    "soal": "Senjata roket militer yang memiliki sistem pengendali otomatis untuk mencari target?",
    "jawaban": "Rudal"
  },
  {
    "index": 133,
    "soal": "Sindikat kejahatan terorganisir di Jepang yang memiliki cara dan hukum mereka sendiri?",
    "jawaban": "Yakuza"
  },
  {
    "index": 134,
    "soal": "Golongan cendekiawan yang juga merupakan golongan karya atau warna dalam agama Hindu?",
    "jawaban": "Brahmana"
  },
  {
    "index": 135,
    "soal": "Musim kering pada daerah tropis yang dipengaruhi oleh sistem muson?",
    "jawaban": "kemarau"
  },
  {
    "index": 136,
    "soal": "Sekolah umum yang kurikulumnya terdapat pelajaran-pelajaran tentang ke-islaman?",
    "jawaban": "Madrasah"
  },
  {
    "index": 137,
    "soal": "Tanaman yang dapat tumbuh tanpa air pada waktu yang lama, ada di daerah gurun?",
    "jawaban": "Kaktus"
  },
  {
    "index": 138,
    "soal": "Sebuah ordo berjari lima dari mamalia, diantaranya termasuk lemur, kera, dan manusia?",
    "jawaban": "Primata"
  },
  {
    "index": 139,
    "soal": "Blus tradisional wanita yang terbuat dari bahan tipis, dikenakan dengan sarung atau batik?",
    "jawaban": "Kebaya"
  },
  {
    "index": 140,
    "soal": "Jenis protein yang biasanya terkandung di dalam gandum, dihindari penderita celiac?",
    "jawaban": "Gluten"
  },
  {
    "index": 141,
    "soal": "Olahraga bela diri yang dikembangkan oleh para Afrika di Brasil pada tahun 1500an?",
    "jawaban": "Capoeira"
  },
  {
    "index": 142,
    "soal": "Peristiwa pengikisan padatan seperti batuan/tanah akibat transportasi angin, air, atau es?",
    "jawaban": "Erosi"
  },
  {
    "index": 143,
    "soal": "Ikan yang merupakan kerabat dekat ikan tuna, sering diolah menjadi kerupuk, siomay, pempek?",
    "jawaban": "Ikan tenggiri"
  },
  {
    "index": 144,
    "soal": "Sebuah jenis tari pergaulan tradisional masyarakat Sunda, khusunya daerah Karawang?",
    "jawaban": "Jaipongan"
  },
  {
    "index": 145,
    "soal": "Sistem bilangan dimana penulisan angka menggunakan dua simbol yaitu 0 dan 1?",
    "jawaban": "Biner"
  },
  {
    "index": 146,
    "soal": "Rempah dari biji keluarga jahe-jahean, merupakan rempah termahal ketiga di dunia?",
    "jawaban": "Kapulaga"
  },
  {
    "index": 147,
    "soal": "Benua yang meliputi Kutub Selatan bumi memiliki suhu yang sangat rendah?",
    "jawaban": "Antartika"
  },
  {
    "index": 148,
    "soal": "Senjata pelontar yang banyak digunakan pada Abad Pertengahan untuk menghancurkan dinding?",
    "jawaban": "Trebuset"
  },
  {
    "index": 149,
    "soal": "Serpihan putih yang merupakan pengelupasan kulit mati berlebihan di kepala?",
    "jawaban": "Ketombe"
  },
  {
    "index": 150,
    "soal": "Ilmu yang mempelajari bahasa dalam naskah-naskah manuskrip zaman kuno?",
    "jawaban": "Filologi"
  },
  {
    "index": 151,
    "soal": "Susu yang hanya dihasilkan pada tahap akhir kehamilan beberapa hari setelah melahirkan?",
    "jawaban": "Kolostrum"
  },
  {
    "index": 152,
    "soal": "Tanaman asli Jepang terasa tajam/pedas yang dimakan sebagai penyedap masakan Jepang?",
    "jawaban": "Wasabi"
  },
  {
    "index": 153,
    "soal": "Olahraga yang menggunakan tongkat pemukul, lapangannya berbentuk bujur sangkar?",
    "jawaban": "Bisbol"
  },
  {
    "index": 154,
    "soal": "Bumbu khas untuk masakan Batak Toba yang juga dikenal sebagai merica Batak?",
    "jawaban": "Andaliman"
  },
  {
    "index": 155,
    "soal": "Sistem pemerintahan yang dianut oleh negara Inggris, Jepang, Belanda, Malaysia, Singapura?",
    "jawaban": "Parelementer"
  },
  {
    "index": 156,
    "soal": "Makanan tradisional Korea berupa asinan sayur hasil fermentasi yang diberi bumbu pedas?",
    "jawaban": "Kimchi"
  },
  {
    "index": 157,
    "soal": "Istilah untuk sesuatu yang bertujuan sosial atau lingkungan, bukan bertujuan keuntungan materi?",
    "jawaban": "Nirlaba"
  },
  {
    "index": 158,
    "soal": "Gerakan yang memperjuangkan kesetaraan bagi perempuan dalam politik, ekonomi, budaya, dsb?",
    "jawaban": "Feminisme"
  },
  {
    "index": 159,
    "soal": "Minuman hasil fermentasi teh dan gula yang berasal dari Asia Timur?",
    "jawaban": "Kombucha"
  },
  {
    "index": 160,
    "soal": "Kelompok garis kerras dari Rusia tahun 1903 yang berpikir perubahan harus dimenangkan dengan senjata?",
    "jawaban": "Bolshevic"
  },
  {
    "index": 161,
    "soal": "Nama pulau vulkanik yang berada di tengah Danau Toba Sumatera Utara?",
    "jawaban": "Samosir"
  },
  {
    "index": 162,
    "soal": "Prajurit pada zaman Yunani Kuno, berfungsi sebagai penombak dalam formasi phalanx?",
    "jawaban": "Hoplites"
  },
  {
    "index": 163,
    "soal": "Nama dari sebuah pekan yang terdiri dari 5 hari dalam budaya Jawa dan Bali?",
    "jawaban": "Pancawara"
  },
  {
    "index": 164,
    "soal": "Cara penyajian makanan pada masa kolonial Belanda dengan berbagai macam hidangan Nusantara?",
    "jawaban": "Rijsttafel"
  },
  {
    "index": 165,
    "soal": "Istilah untuk budidaya menanamdengan memanfaatkan air tanpa menggunakan tanah?",
    "jawaban": "Hidroponik"
  },
  {
    "index": 166,
    "soal": "Jenis logam paling berlimpah di Bumi, merupakan konduktor listrik yang paling baik?",
    "jawaban": "Aluminium"
  },
  {
    "index": 167,
    "soal": "Sebuah organisasi ekonomi berdasarkan ekonomi rakyat dan asas kekeluargaan?",
    "jawaban": "Koperasi"
  },
  {
    "index": 168,
    "soal": "Hari raya umat hindu, dirayakan setiap 210 hari menggunakan perhitungan kalender Bali?",
    "jawaban": "Galungan"
  },
  {
    "index": 169,
    "soal": "Ilmu yang mempelajari bentuk permukaan bumi serta permukaan planet, satelit alami, asteroid?",
    "jawaban": "Topografi"
  },
  {
    "index": 170,
    "soal": "Persembahan kepada dewa atau arwah nenek moyang oleh penganut kepercayaan kuno di Indonesia?",
    "jawaban": "Sesajen"
  },
  {
    "index": 171,
    "soal": "Judul lagurakyat Korea, sekaligus simbol Korea, dikenal di Korea Utara maupun Korea Selatan?",
    "jawaban": "Arirang"
  },
  {
    "index": 172,
    "soal": "Istilah bentuk bangsa pengembara yang memilih hidup berpindah-pindah untuk bertahan hidup?",
    "jawaban": "Nomaden"
  },
  {
    "index": 173,
    "soal": "Sejenis jamur pinus langka yang menjadi bahan makanan mewah berharga mahal di Jepang?",
    "jawaban": "Matsutake"
  },
  {
    "index": 174,
    "soal": "Suatu adat masyarakat yang mengatur alur keturunan berasal dari pihak ibu?",
    "jawaban": "Matrilineal"
  },
  {
    "index": 175,
    "soal": "Padang rumput yang dipenuhi semak dan beberapa jenis pohon yang tumbuh menyebar?",
    "jawaban": "Sabana"
  },
  {
    "index": 176,
    "soal": "Penjelajah asal italia yang menemukan benua amerika pada tahun 1492?",
    "jawaban": "Capoerira"
  },
  {
    "index": 177,
    "soal": "Skor atau skala yang digunakan unuk menilai kondisi kesehatan bayi yang baru lahir?",
    "jawaban": "Apgar"
  },
  {
    "index": 178,
    "soal": "Salah satu pulau di Sulawesi Utara yang memiliki biodiversitas kelautan tertinngi di dunia?",
    "jawaban": "Bunaken"
  },
  {
    "index": 179,
    "soal": "Ahli pengaplikasian ilmu keuangan dan teori statistik pada persoalan bisnis aktual?",
    "jawaban": "Aktuaris"
  },
  {
    "index": 180,
    "soal": "Tradisi sepasang pengantin meminta doa restu kepada orang tua kedua belah pihak?",
    "jawaban": "Sungkem"
  },
  {
    "index": 181,
    "soal": "Jenis saus berwarna putih yang terbuat dari minyak nabati, telur ayam, dan cuka?",
    "jawaban": "Mayones"
  },
  {
    "index": 182,
    "soal": "Istilah yang artinya tidak memberikan suara atau sikap dalam sebuah pemungutan suara?",
    "jawaban": "Abstain"
  },
  {
    "index": 183,
    "soal": "Salah satu bunga nasional indonesia memiliki julukan sebagai puspa bangsa?",
    "jawaban": "Melati"
  },
  {
    "index": 184,
    "soal": "Alat musik dawai yang dimainkan dengan cara dipetik, berasal dari Rote, NTT?",
    "jawaban": "Sasando"
  },
  {
    "index": 185,
    "soal": "Batu yang menggantungkan dan meneteskan air dari langit-langit gua kapur?",
    "jawaban": "Stalaktit"
  },
  {
    "index": 186,
    "soal": "Ikon negara singapura berupa patung berkepala singa dengan berbadan ikan?",
    "jawaban": "Merlion"
  },
  {
    "index": 187,
    "soal": "Istilah dalam catur ketika posisi raja tidak bisa lepas dari pergerakan lawan?",
    "jawaban": "Sekakmat"
  },
  {
    "index": 188,
    "soal": "Alat untuk mengukur tekanan udara, digunakan dalam peramalan cuaca?",
    "jawaban": "Barometer"
  },
  {
    "index": 189,
    "soal": "Presiden amerika ke 32 satu-satunya yang terpilih sebanyak 4 kali?",
    "jawaban": "Roosevelt"
  },
  {
    "index": 190,
    "soal": "Jenis rumah arsitektur tradisional Jawa terbangun dari empat tiang utama?",
    "jawaban": "Limasan"
  },
  {
    "index": 191,
    "soal": "Istilah bahasa Jepang untuk karakter gambar yang digunakan dalam pesan elektronik?",
    "jawaban": "Emoji"
  },
  {
    "index": 192,
    "soal": "Salah satu senjata belati khas Nusantara yang seringkali bilahnya berkelok-kelok?",
    "jawaban": "Keris"
  },
  {
    "index": 193,
    "soal": "Penduduk asli benua Australia yang berciri kulit gelap dan rambut keriting?",
    "jawaban": "Aborigin"
  },
  {
    "index": 194,
    "soal": "Tarian khas suku gayo dari aceh, ditampilkan untuk merayakan peristiwa penting?",
    "jawaban": "Tari saman"
  },
  {
    "index": 195,
    "soal": "Bentuk muda serangga atau amfibia yang perkembangannya melalui metamorfosis?",
    "jawaban": "Larva"
  },
  {
    "index": 196,
    "soal": "Tempat kapal ditambatkan di pelabuhan untuk kegiatan bongkar muat barang?",
    "jawaban": "Dermaga"
  },
  {
    "index": 197,
    "soal": "Jenis jam tangan yang digerakkan oleh mesin bertenaga listrik atau baterai?",
    "jawaban": "Quartz"
  },
  {
    "index": 198,
    "soal": "Suku penganut Agama Hindu yang tinggal di sekitar pegunungan Bromo dan Semeru?",
    "jawaban": "Tengger"
  },
  {
    "index": 199,
    "soal": "Mainan yang bisa berputar padaporos dan berkesetimbangan pada suatu titik?",
    "jawaban": "Gasing"
  },
  {
    "index": 200,
    "soal": "Tanaman polong-polongan yang merupakan sumber utama protein nabati dunia?",
    "jawaban": "Kedelai"
  },
  {
    "index": 201,
    "soal": "Cairan tidak berwarna, tidak berbau, digunakan sebagai senjata kimia pemusnah massal?",
    "jawaban": "Sarin"
  },
  {
    "index": 202,
    "soal": "Cabang ilmu kedokteran gigi yang khusus mempelajari ilmu merapikan gigi?",
    "jawaban": "Ortodonti"
  },
  {
    "index": 203,
    "soal": "Sstilah yang berasal dari Bahasa Italia, artinya penari baletperempuan?",
    "jawaban": "Balerina"
  },
  {
    "index": 204,
    "soal": "Sawah berundak di Bali yang diakui UNESCO sebagai Warisan Budaya Dunia?",
    "jawaban": "Jatiluwih"
  },
  {
    "index": 205,
    "soal": "Makanan pokok pengganti nasi yang dibuat dari ketela pohon atau singkong?",
    "jawaban": "Tiwul"
  },
  {
    "index": 206,
    "soal": "Bagian mata yang mengubah cahaya menjadi sinyal saraf?",
    "jawaban": "Retina"
  },
  {
    "index": 207,
    "soal": "Nama mesin penyandi yang digunakan Jerman nazi pada Perang Dunia II?",
    "jawaban": "Enigma"
  },
  {
    "index": 208,
    "soal": "Kosmetika yang terbuat dari lilin, pigmen, minyak, diaplikasikan pada bibir?",
    "jawaban": "Lipstik"
  },
  {
    "index": 209,
    "soal": "Bumbu makanan yang terbuat dari fermentasi kedelai, terigu, dan garam?",
    "jawaban": "Tauco"
  },
  {
    "index": 210,
    "soal": "Hewan renik yang dapat menurunkan produktivitas hewan yang diumpanginya?",
    "jawaban": "Parasit"
  },
  {
    "index": 211,
    "soal": "Cairan manis yang diproduksi bunga untuk menarik kedatangan hewan penyerbuk?",
    "jawaban": "Nektar"
  },
  {
    "index": 212,
    "soal": "Proses pembuatan daratan baru dari dasar laut atau dasar sungai?",
    "jawaban": "Reklamasi"
  },
  {
    "index": 213,
    "soal": "Istilah untuk keadaan niat sebelum melaksanakan ibadah Haji atau Umroh?",
    "jawaban": "Ihram"
  },
  {
    "index": 214,
    "soal": "Alat musik senar khas suku Banjar, dimainkan dengan cara dipetik?",
    "jawaban": "Panting"
  },
  {
    "index": 215,
    "soal": "Penyakit virus mematikan yang mewabah di Afrika Barat tahun 2014?",
    "jawaban": "Ebola"
  },
  {
    "index": 216,
    "soal": "Jenis musang yang dikenal suka menyantap biji kopi secara utuh?",
    "jawaban": "Luwak"
  },
  {
    "index": 217,
    "soal": "Nama pedang yang dimiliki raja Arthur menurut mitologi Britania Raya?",
    "jawaban": "Excalibur"
  },
  {
    "index": 218,
    "soal": "Negara yang memiliki bendera merah putih persis seperti Indonesia?",
    "jawaban": "Monako"
  },
  {
    "index": 219,
    "soal": "Suatu pertunjukan teater yang menggunakan isyarat gerak tubuh tanpa suara?",
    "jawaban": "Pantomim"
  },
  {
    "index": 220,
    "soal": "Tradisi pernikahan calon mempelai wanita tidak diperkenankan keluar rumah?",
    "jawaban": "Pingitan"
  },
  {
    "index": 221,
    "soal": "Tipe hewan yang beraktivitas pada malam hari dan tidur pada siang hari?",
    "jawaban": "Nokturnal"
  },
  {
    "index": 222,
    "soal": "Kelainan bawaan tidak adanya pigmen melanin pada mata, kulit, rambut?",
    "jawaban": "Albinisme"
  },
  {
    "index": 223,
    "soal": "Cabang ilmu linguistik yang mempelajari asal usul kata?",
    "jawaban": "Etimologi"
  },
  {
    "index": 224,
    "soal": "Jenis ikan yang dapat melompat kedaratan, terdapat di Pulau Kalimantan?",
    "jawaban": "Tembakul"
  },
  {
    "index": 225,
    "soal": "Mata uang elektronik dengan teknologi blockchain yang diciptakan pada tahun 2009?",
    "jawaban": "Bitcoin"
  },
  {
    "index": 226,
    "soal": "Pengusaha rokok terbesar tahun 1918 pemilik pabrik kretek tjap bal tiga?",
    "jawaban": "Nitisemito"
  },
  {
    "index": 227,
    "soal": "Pelukis ekspresionis ini dikenal sebagai maestro seni lukis Indonesia?",
    "jawaban": "Affandi"
  }
]